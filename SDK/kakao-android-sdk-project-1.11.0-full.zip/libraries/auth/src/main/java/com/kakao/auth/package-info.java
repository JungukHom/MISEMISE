/**
 * Kakao Android SDK 내부에서 사용하는 인증관련 패키지로 로그인관련 클래스가 포함되어있다.
 */
package com.kakao.auth;