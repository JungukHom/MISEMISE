/**
 * Package for classes related to authorization to Kakao API, including getting authorization code
 * and access token.
 */
package com.kakao.auth.authorization;