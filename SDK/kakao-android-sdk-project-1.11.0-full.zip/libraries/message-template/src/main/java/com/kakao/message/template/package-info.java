/**
 * Package for template parameter classes for message template v2.
 */
package com.kakao.message.template;