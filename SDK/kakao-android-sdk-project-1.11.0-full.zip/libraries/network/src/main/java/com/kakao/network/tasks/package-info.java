/**
 * 카카오 Api를 사용할때 background에서 동작할 수 있는 Task를 제공한다.
 */
package com.kakao.network.tasks;