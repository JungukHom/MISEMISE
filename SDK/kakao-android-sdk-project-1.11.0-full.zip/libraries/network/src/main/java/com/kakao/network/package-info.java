/**
 * Provide HTTP network module used throughout the SDK. Classes in this package are subject to change
 * so use at your own discretion.
 */
package com.kakao.network;