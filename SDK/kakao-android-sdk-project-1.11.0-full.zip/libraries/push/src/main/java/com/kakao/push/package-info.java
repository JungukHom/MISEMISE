/**
 * Provide API for push messages on apps logged in via Kakao account.
 */
package com.kakao.push;